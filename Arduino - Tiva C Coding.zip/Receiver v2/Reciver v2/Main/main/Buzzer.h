#ifndef __Buzzer__
#define __Buzzer__

#define Mute      0
#define Ring      1

void Buzzer_Init(void);
void Buzzer_State(unsigned char State);

#endif
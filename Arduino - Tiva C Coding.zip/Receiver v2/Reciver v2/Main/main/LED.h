#ifndef __LED__
#define __LED__

#define LED_OFF      0
#define LED_ON       1

void LED_Init(void);
void LED_State(unsigned char State);

#endif
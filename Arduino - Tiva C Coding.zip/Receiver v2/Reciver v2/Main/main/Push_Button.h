#ifndef __Push_Button__
#define __Push_Button__

void Push_Button_Init(void);
unsigned char Push_Button_State(void);

#endif